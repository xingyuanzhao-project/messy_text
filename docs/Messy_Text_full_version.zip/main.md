# Introduction

Many valuable text data and annotations were created before the
standards and data structures now expected in LLM based research. These
materials preserve costly human judgment and domain knowledge, yet they
were often not gathered, organized, or annotated in ways that make them
directly usable for contemporary computational workflows. This creates a
central research problem: how can researchers use or reuse legacy texts
and annotations without losing their original knowledge while making
them usable for modern LLM based analysis.

Our goal is to reuse the prior data collection and annotations to create
a clean corpus. Addressing downstream tasks using real-world data,
researchers often must work with messy texts. In this research, we refer
to the text that has heterogeneous noises, confounding content, and
structural misalignment as *messy texts*. These texts are scraped
websites and documents from previous works that may contain irrelevant
formatting and information resulting from poor web scraping, connection
errors, or faulty parsing, such as navigation menus, error pages, cookie
consent notices, and social media sharing buttons interspersed with
article content, creating noise that will distract the model from the
useful content. What might be worse is that, these texts might contain
seemingly related but essentially unrelated information as distractions,
originating from suggested articles or user comments on the article
page, introducing hallucinations and conflation of events for the LLMs.
Additionally, these texts might not be organized or structured in a way
that is ready for processing by modern text-as-data methods, making it
unsuitable for the LLMs for it will further confuse the model.

Our example here is based on a corpora of annotated texts about
disappearances of persons in Mexico. The initial collection of these
heterogeneous corpus requires a systematization and coding, applying a
consistent analytical framework to materials that were not originally
collected under uniform criteria. Each case identified in the press
corpus was reviewed and, where possible, translated into a structured
set of variables capturing key dimensions of the disappearance. But
given the nature of the original corpus, this often involved
interpretive reconstruction. Press reports often contain incomplete,
inconsistent, or ambiguous information, requiring careful reading and,
in some cases, comparison across multiple articles related to the same
case. Even when multiple reports exist, discrepancies between sources
are common, particularly in relation to causes of disappearance,
involvement of authorities, or outcomes of investigations.

The press-based corpus analyzed in this study originates not as a fully
standardized database but as a fragmented and heterogeneous collection
of newspaper articles. Through processes of systematization and coding,
this study transforms these materials into a structured analytical
dataset that enables the examination of both patterns of disappearance
and the ways in which they are represented in public discourse. The
limitations and inconsistencies of the corpus are integral to the
analysis, revealing the challenges of documenting and understanding
disappearances in contexts marked by violence, uncertainty, and
impunity.

The original annotations were made with the victim as the unit of
analysis, recording codebook fields such as method of capture and who
carried out the threats for each person. As for the corpora itself, the
documents were collected and organized by news source rather than by
victim, so any single victim's record is distributed across multiple
documents whose linkage back to the annotations cannot realistically be
reconstructed by human labor. This misalignment matters for downstream
use, since fine-tuning and classification over news reports operate on
individual documents and therefore require labels that hold at the
document level. A victim's method of capture may appear in one report
while the identity of those who carried out the threats appears in
another, yet both were annotated at the victim level without reference
to a specific document. Propagating victim-level annotations onto every
document in which the victim appears would therefore train downstream
models on incorrect signals, because many of those documents do not
contain the evidence for the label they would inherit.

*Humans can easily filter and extract around this noise and may have
already done so to produce annotations*. But to extend this with the
latest LLMs one needs to a) clean the texts (explicitly) and b)
reconnect the human annotations to the modern needs to LLMs (e.g., span
annotations rather than just words or linkages to actual images in a
larger document) [@olsen-etal-2024-socio]. The core problems here are
not only cleaning noisy text, but also aligning annotations created by
human coders who can infer structure from dispersed evidence across
multiple documents, with the exact source spans where these annotations
come from, using LLM workflows.

Solving these problems allows researchers to work with and re-use texts
for their research but that are currently messy and not well-structured.
For example, legacy annotated corpora may have codings that are not
linked to the spans or chunks in a level that is suitable for modern
text as data research [@Escott2018]. Corpora that are multi-document
aligned with other units of analysis have evidence about a single case
dispersed across thousands of pages and many persons, making the
material hard to navigate and requires additional retrieval structures
that can be solved by using LLMs [@Gibbs_etal2010]. And digitized
archives and other scraped web corpora such like congressional hearings
or news archives also face semantic confounding contents that cannot be
simply removed by rule-based approaches
[@HurtadoBodell_etal2022; @Molina_etal2025]. Our application is a corpus
on cases of disappeared people that is valuable and significant for
human rights' research as well as serving training for the
classification and prediction of the commission of future crimes . We
propose a multi-turn extractive summarization method that sequentially
processes the original messy and disorganized documents for each unit of
analysis (victim). This is done with a conversation state that
iteratively updates the running summary with exact text spans from new
documents, generating a summary by item for each victim, comprised of
sentences extracted from the report that are directly relevant to the
item.

From a broader point of view, this work contributes a generalizable
pipeline for aligning prior victim-level annotations with document-level
source spans, producing evidence-traceable outputs that reuse existing
codebooks without re-collection. This work also demonstrates a better
way of using LLMs to assist social science research that is more robust
to hallucination and other biases by using a multi-turn stateful
workflow framework that maintains context across operations and allows
tracking the source and evidence of the information extracted from the
text.

A further contribution concerns the use of the pipeline output as
training data for downstream model adaptation. The codebook-guided
summaries produced by this workflow are structured, label-aligned, and
free of the noise that makes the original scraped documents unsuitable
for supervised learning. Each summary is organized by codebook field,
with extracted evidence spans linked to their source documents, which
means the pipeline output can serve directly as input--output pairs for
fine-tuning smaller, task-specific classifiers.

# Related Work

We review and consider three approaches for aligning and re-using our
prior texts and their annotations. These are detailed below as *non-LLM
methods*, and *LLM-methods* both of which are mainly extractive
approaches that would either use human or text-as-data methods. The
final approach we advocate and develop is a hybrid approach that uses
both generative and extractive LLM methods, which we call *extraction
and summarization* (see [@Brandt_etal2025] for a discussion of these
distinctions).

## Non-LLM Methods for Messy Text

Producing a clean, structured dataset from noisy web-scraped text while
preserving traceable connections to the original source material has
typically relied on rule-based preprocessing, manual data cleaning, or a
combination of both [@Bohannon_etal2007; @OpenRefine2025]. Rule-based
methods can remove structural elements, but because each source website
uses a different page layout they do not generalize reliably across
heterogeneous sources and cannot handle semantically related but
contextually irrelevant content such as suggested article previews or
reader comment threads [@Rahm2011; @Ma_etal2025]. Human labor can handle
these contextual distinctions, but at the volume of a large web-scraped
corpus it becomes prohibitively slow, expensive, and inconsistent,
making both approaches insufficient for the noisy corpus examined in
this paper [@Ma_etal2025; @Ni_etal2024].

Both rule-based preprocessing and human labor are insufficient for
handling the noisy corpus and realign the unit of analysis. Rule-based
preprocessing cannot reliably disentangle noise with semantic similarity
to target content, and provides no traceable path from annotations back
to the source spans that justify them. Re-applying human labor to align
the unit of analysis at the scale of this corpus creates a timeframe
that is not feasible.

## LLM Methods for Messy Text

Recent work suggests that LLMs are well suited to messy text beyond the
limits of rule based methods because they can use contextual reasoning
to distinguish relevant content from noise across heterogeneous sources.
These literature include both direct cleaning tasks and related
annotation tasks, together showing that language models can support data
preparation when rule based methods are too rigid for noisy text.

LLM based work has been applied to messy news text. For example,
Multi-News+ classifies noisy news reports into categories, which makes
it similar to our task in the basic sense that both separate useful text
from noise [@Choi_etal2024]. It does not directly solve our problem,
however, because our goal is not to classify already defined document
inputs, but to identify and preserve relevant information within noisy
documents while keeping it traceable to the source text. This work
contributes by showing that models can handle messy text and support
data quality tasks. A closely related project is the application Ventana
a la Verdad, a retrieval-augmented chatbot over the Colombian Truth
Commission's archives, which creates interactive question-answering
chatbot rather than codebook-aligned summaries linked to document-level
source spans. Another issue it does not solve is the realignment of the
unit of analysis.[@Sokol_etal2025].

LLMs can also perform the data standardization and data error processing
tasks that rule based preprocessing was originally meant to provide,
because they can infer these transformations from context rather than
relying on site specific
rules [@Ma_etal2023; @Zhang_etal2024; @Choi_etal2024; @Biester_etal2024; @Li_etal2024; @Yan_etal2024].
They can also perform data integration, especially entity matching, and
this supports annotation source tracing by preserving the link between
each extracted annotation and the source document or spans from which it
originates [@Peeters_etal2025; @Wang_etal2025; @Fan_etal2024]. By
contrast, data imputation does not fit our purpose because our goal is
not to infer absent information, but to identify and preserve
information that is already present in noisy text, and generating
plausible missing values would weaken traceability to the source text
and increase the risk of unsupported
outputs [@Ding_etal2024; @He_etal2025]. These existing works suggest
that these models are capable of distinguishing relevant content from
noise and of addressing these data preparation problems in heterogeneous
text, providing the foundation for the design developed in the following
sections [@Zhou_etal2026].

## Extraction and Summarization

The literature that does summarization using LLMs usually assumes
cleaner and more standardized inputs than the corpus here. Many methods
operate on texts that already have stable document
boundaries [@Choi_etal2024], clearer annotation targets [@Ma_etal2023],
or outputs defined at the same level as the input
text [@Zhang_etal2024]. Our setting differs because the corpus is messy,
the source documents were not aligned with the unit of analysis for the
downstream tasks, which creates specific methodological issues. Pure
cleaning would not recover the missing link between earlier annotations
and the source text, and unconstrained generation is not enough because
paraphrasing weakens grounding and traceability. The task instead
requires a hybrid design that extracts source grounded evidence from
messy documents [@Dagdelen_etal2024] and uses that evidence to produce
clean structured summaries for downstream use [@olsen-etal-2024-socio],
so that they will produced in the form that current extraction and
summarization workflows require while preserving human annotations.
Reannotation would require time, funding, and domain expertise that are
no longer available at the necessary scale, while leaving the legacy
annotations untouched would preserve the same gap between old coding
work and modern LLM inputs.

The main solution is then to design a workflow that recovers traceable
evidence from messy text, produces clean summaries for downstream use,
and reuses prior annotations without pretending that the original human
process can be recreated. Even though the related work has already shown
LLMs are suitable for this task, but the others approaches cannot be
simply reapplied here. We therefore choose a combined approach that uses
LLMs to extract source grounded evidence and produce clean structured
summaries, so that prior annotations can be reused without full
reannotation and downstream tasks can operate on text that is both
traceable and usable.

# Method

To address the mismatch between victim level annotations and document
level source reports while providing a clean summarization, the workflow
is organized into three linked tasks. For each report, it identifies
source grounded evidence, converts that evidence into a structured
document level summary, and then revises the running summary as later
reports add or refine information.
Figure [1](#fig:workflow_diagram_1){reference-type="ref"
reference="fig:workflow_diagram_1"} illustrates this document to summary
update process, and the following subsections explain each stage.

<figure id="fig:workflow_diagram_1" data-latex-placement="tbp">

<figcaption>Workflow for extracting evidence, generating a structured
summary, and updating the running summary across sequential documents.
Each turn processes one document against the shared codebook schema: the
model extracts verbatim spans with character offsets, generates a
label-by-label summary anchored to those spans, then updates the running
per-victim summary <span
class="math inline"><em>S</em><sub><em>i</em></sub></span>, which is
carried into the next turn as conversation state.</figcaption>
</figure>

The task is to reuse the existing codebook and human annotations by
aligning them with the original texts, extracting source grounded
evidence for each coded field, producing clean structured document level
summaries, and updating those summaries across multiple reports while
preserving traceability to the supporting spans. The following
subsections explain how each of these tasks is implemented.

## Task Definitions

The task is to transform a set of messy, multi document news reports
associated with a single victim into a structured, evidence traceable
document level representation that supports reuse of the existing
codebook and annotations.

Another critical requirement is that the output text must be noise-free,
so that any further LLM tasks can be meaningful. The text must combine
extraction of verbatim spans with structured aggregation across
documents, so that the resulting representation is both clean enough to
serve as LLM input and anchored tightly enough to the source material to
support reuse of the existing coded data and codebook definitions.

## Model Setup

All LLM calls were executed using instruction tuned models served
through vLLM [@Kwon_etal2023]. The default configuration uses the AWQ
INT4 quantized Meta Llama 3.1 8B Instruct model [@Dubey_etal2024], and
cross model comparisons use Meta Llama 3.1 70B Instruct, Gemma 3 12B
IT [@GemmaTeam2025], and Ministral 3 8B Instruct [@MistralAI2026]. We
use deterministic decoding with temperature 0.0. Generation is capped at
1024 tokens for summarization and 256 tokens for classification, and
outputs are constrained to a fixed JSON schema to produce consistent
structured fields for extracted spans and label predictions. To probe
whether the gains reported below are specific to small open-source
models or hold across model tiers, we also ran the same pipeline through
the Claude 4.x family (Haiku 4.5, Sonnet 4.6, Opus 4.7) on a 100-victim
subsample drawn with a fixed seed; results are reported in
Section [6.3](#closed-source-comparison){reference-type="ref"
reference="closed-source-comparison"}.

::: {#tab:processing-time}
  Model                                                       Time GPU
  -------------------------------- ------------------------------- ------
  Llama-3.1-8B-Instruct-AWQ-INT4     $\sim$`<!-- -->`{=html}34 min A100
  Ministral-3-8B-Instruct-2512       $\sim$`<!-- -->`{=html}51 min A100
  Gemma-3-12B-IT-INT4-AWQ            $\sim$`<!-- -->`{=html}38 min A100

  : Processing time per model.
:::

## Pipeline

The pipeline takes each victim's documents one at a time in sequence,
extracting relevant spans, generating a label-structured summary
anchored to those spans, and updating the summaries using previous
summaries as context. This pipeline satisfies the task definition by
producing document level outputs that are clean enough for downstream
language model use while keeping each coded field traceable to evidence
in the original documents.

In the first step of the pipeline, we extract evidence rather than only
generating a paraphrased summary. For each input document, the model is
instructed to return verbatim text spans for each item in the codebook
schema, producing a structured evidence record keyed by label. This
creates traceability because every coded field is paired with the exact
source phrase that supports it, so downstream users can verify where the
information came from in the original report. The evidence output is
designed to demonstrate that the link between each annotation and its
source text is preserved and can later be verified, and it also includes
a character index that locates each span within the document text. This
index records how many characters into the document the extracted span
begins, so a future researcher can find the exact spot in the original
text and confirm the evidence.

In the second step of the workflow, we generate a coherent summary while
keeping it anchored to evidence and guided by the codebook schema. The
model is given the document text together with the label definitions
that specify the meaning of the labels and how the human coders would
code the information, and it is also provided with the extracted span
structure so that each sentence or clause of the summary can be linked
back to the corresponding evidence. For example, the first sentence may
be about the victim, and the second sentence may be about the method of
capture, and the third sentence may be about who carried out the
threats, instead of condensing the information into a single sentence
where all the information is mixed together. This makes the summary
different from vanilla summarization because it is not an unconstrained
paraphrase of the document, rather, with the paragraph structured label
by label, it will be easier for an LLM to pick up the right information.
At this stage, summarization is performed at the level of a single
document and is designed to be clean, structured, and directly usable
for downstream models.

In a typical single request, an LLM is stateless, meaning that it does
not retain information from earlier calls, but our workflow preserves
memory by maintaining an explicit conversation state for each victim as
their documents are processed. The workflow maintains an explicit
conversation state for each victim that accumulates across documents as
they are processed sequentially. The prompt instructs the model to check
each new document against the existing summary and update only the
fields where new information is found. If a document contains no
relevant information, the runner keeps the previous summary unchanged
rather than replacing it with the model's output. Each turn also records
the output of that turn, preserving what was extracted and what summary
was produced at that step for later inspection and reuse. When a
document contains no relevant information, the workflow avoids replacing
the existing running summary, so the accumulated context is not lost as
the sequence progresses.

# Data

## Press-based Corpus Data Source {#data-source}

The texts are a press-derived corpus of disappearance cases in Mexico,
developed in collaboration with the University of Minnesota's Human
Rights Program, Oxford University, Universidad Autónoma de Mexico
(UNAM), and the Facultad Latinoamericana de Ciencias Sociales
(FLACSO-México), as part of broader research on disappearances,
**impunity**, and media representation. The corpus consists of newspaper
articles collected over time (**2016-2021**), primarily from regional
outlets, with a focus on Nuevo León, Coahuila, Tamaulipas, Jalisco, and
Guerrero. which have experienced sustained patterns of disappearances
**of people** since the escalation of violence after **the so-called
\"\"War on Drugs\" in 2006.**

Rather than originating as a unified or systematically constructed
database, the corpus was initially assembled as a collection of
newspaper "clips" gathered by multiple coders and researchers working at
different times. These materials were identified through keyword
searches using variations of terms such as *desaparición, secuestro,
extraviado*, and *levantón*, and were selected when they referred to
identifiable individuals reported missing or whose **fate and**
whereabouts remained unknown. The corpus does not follow a single,
standardized methodology at the stage of collection, reflecting an
accumulative process shaped by diverse research practices and
institutional contexts. Therefore, there is considerable variation in
the criteria used to identify cases, the depth of information recorded,
and the degree to which cases were tracked over time. Some cases are
documented through multiple articles, while others appear only once,
with no follow-up reporting. This lack of initial methodological
uniformity is not merely a technical limitation but an important feature
of the data. It reflects the broader fragmentation of information
surrounding disappearances in Mexico.

Several limitations arise from the nature of the press corpus. First,
the dataset is characterized by initial methodological inconsistency,
reflecting its origins as a collection of articles compiled without a
unified protocol. While the subsequent coding process introduces a
degree of analytical coherence, variations in source selection and
reporting practices remain. Second, press coverage itself is uneven and
often incomplete. Many disappearance cases are reported only briefly and
without follow-up, limiting the amount of information available for
analysis. This results in gaps in the dataset and constrains the ability
to reconstruct events in detail. Finally, because the corpus is derived
exclusively from press sources, it reflects the selective visibility of
cases. Not all disappearances are reported in the media, and those that
are reported may not be representative of the broader universe of cases.

## Descriptive Statistics

The main annotated corpus contains information about 575 victims and
2,229 source reports.
Figure [2](#fig:corpus_distributions){reference-type="ref"
reference="fig:corpus_distributions"}(a) shows the distribution of the
reports (documents) associated with each victim. These vary
considerably, with a median of 3 and a mean of 4, and a range from a
single document to 16. Most victims have between one and three
associated reports, while a smaller number are covered by ten or more.
Report length also varies widely across the corpus, with a median of
approximately 5,500 characters and a mean of approximately 7,100, but
the distribution has a long right tail, with individual reports reaching
over 130,000 characters as shown in
Figure [2](#fig:corpus_distributions){reference-type="ref"
reference="fig:corpus_distributions"}(b). These distributions indicate
that both the coverage per victim and the length of individual reports
are uneven, which directly encouraged the multi-turn processing pipeline
described in the method section. When concatenating the reports for each
victim, the total length of the concatenated text will be too long for
most LLMs to easily process, which is why we need to use the multi-turn
processing pipeline so that corpora can be naturally processed document
by document as smaller units.

<figure id="fig:corpus_distributions" data-latex-placement="tp">
<img src="./plots/descriptive_statistics/corpus_distributions.png" />
<figcaption>Joint distribution of corpus size. Each point is a victim,
plotted by the number of scraped documents (x-axis) and the median
character count across those documents (y-axis, log scale). Dashed lines
mark the corpus medians. Marginal density curves on the top and right
summarise each axis. The corpus contains 575 victims and
2<span>,</span>229 reports, with most victims having 1–4 documents and
median report length around 5<span>,</span>500 characters.</figcaption>
</figure>

The codebook from the human annotations itself is extensive, spanning
seven sections that cover victim demographics, circumstances of capture,
outcome of the disappearance, perpetrator characteristics, judicial
proceedings, and observational comments, with several dozen substantive
coded variables in total. Not all victims in the corpus have annotations
for every coded field. A substantial portion records free text
descriptions, dates, or geographic identifiers that cannot be used
directly in a classification-based evaluation. Among the categorical
fields that remain, many encode details that are specific to a narrow
research domain, such as the identity of individual organized crime
groups or the type of judicial sentence. The codebook used by the
original human coders instructed them to enter 999 when no information
was available in the news articles, and as a result many labels carry
high rates of missing values across the 575 victims. The degree of
missing values varies substantially from one label to another, depending
on whether the coder was able to find the information in the news
articles for the given victim.[^2]

We select a subset of categorical labels that have relatively low rates
of missing values and that capture information relevant to a broad
audience rather than to a single specialized subfield. Of interest to
use are three variables that meet this criteria. The variable
*Desenlace* records the outcome of the disappearance as reported in the
press. Among the 575 victims, 393 have an annotation for this variable,
each recording has one of the seven possible categories. The
distribution is heavily concentrated where 254 victims are recorded as
still disappeared and 91 as found dead, together accounting for nearly
88 percent of annotated cases, while the remaining five categories,
including liberation by captors or authorities, found alive,
self-liberation, and found without specification of condition, each
contain fewer than 25 cases, as shown in
Figure [11](#fig:desenlace_distribution){reference-type="ref"
reference="fig:desenlace_distribution"}. The *Captura tipo* label
records the type of place where the victim was captured, using place
categories from the HURIDOCS micro-thesaurus. Among the 575 victims, 243
have an annotation for this field, each recording has one of the eight
possible categories. The distribution is heavily concentrated. 90
victims are recorded as means and routes of transport and places of
connection and 81 as places related to the victim such as the home or
workplace, together accounting for over 70 percent of annotated cases,
while the remaining six categories range from 1 to 28 cases, as shown in
Figure [12](#fig:captura_tipo_distribution){reference-type="ref"
reference="fig:captura_tipo_distribution"}. The third label that meets
these criteria, *Vic grupo social*, records the social group to which
the victim belongs. Among the 575 victims, 273 have an annotation for
this field, each recording has one of the ten possible categories. The
distribution is heavily concentrated. 95 victims are recorded as people
who work in service industries, 49 as civil servants, and 45 as
students, together accounting for nearly 70 percent of annotated cases,
while the remaining seven categories, including professionals,
activists, people associated with politics, organized crime, land
workers, and others, each contain smaller counts, as shown in
Figure [13](#fig:vic_grupo_social_distribution){reference-type="ref"
reference="fig:vic_grupo_social_distribution"}.

# Evaluation {#eval_results}

Evaluation of summarization tasks compares the text summary with a gold
standard reference text. Given the messy and noisy initial documents, it
is difficult to use them as reference texts. The prior work has human
annotations classifying the information in the summary text. The
evaluation tests whether generated summaries reproduce the same labels
as the human annotations, comparing a simple summarization baseline
against the proposed method, across major model families, and across
model sizes.

The dataset contains human annotations coded at the victim level, and
these annotations are used as ground truth. The Evaluation proceeds by
classifying the generated clean summary aggregated at victim level and
comparing the resulting labels against the human annotations, testing
whether the summaries preserve the same information that human coders
recorded between the results from a direct generative summarization and
across multiple models. The original codebook contains fine-grained
categories for similar concepts such as Levantón and Secuestro, and the
inherent ambiguity of the source text means that the model and the human
coder may generate different but equally defensible results from the
same spans. Evaluating directly against the fine-grained categories
would penalize valid model outputs. To reduce the number of categories
where multiple valid answers fall into different classes, the original
categories are collapsed into broader groupings before evaluation. The
detailed distribution of the collapsed categories is shown in
Table [2](#tab:selected_labels_distribution_after){reference-type="ref"
reference="tab:selected_labels_distribution_after"}.

Three design choices make the evaluation interpretable. First, all
accuracy and agreement estimates are reported with 95% percentile
bootstrap confidence intervals computed by resampling victims (2,000
resamples), so that differences between methods and models can be read
against sampling uncertainty rather than as bare point estimates.
Second, because the collapsed label spaces are heavily imbalanced
(Table [2](#tab:selected_labels_distribution_after){reference-type="ref"
reference="tab:selected_labels_distribution_after"}), raw accuracy alone
is not an honest yardstick: a classifier that always predicts the most
frequent annotated category can reach high accuracy without reading any
text. We therefore plot a majority-class reference alongside every
accuracy comparison and report Cohen's $\kappa$, which measures
agreement beyond chance, for the cross-model comparison. Third, because
the pipeline's central claim is that extracted evidence spans are
verbatim and traceable,
Section [6.4](#span-fidelity){reference-type="ref"
reference="span-fidelity"} audits every recorded span against the source
documents directly rather than leaving traceability as an assumption.

::: {#tab:selected_labels_distribution_after}
+---------------------------------+--------------------------------+
| Category                        | Count                          |
+:================================+===============================:+
| *Desenlace* (n = 393, missing 182 / 32%, 2 distinct)             |
+---------------------------------+--------------------------------+
| Still disappeared               | 254                            |
+---------------------------------+--------------------------------+
| Found                           | 139                            |
+---------------------------------+--------------------------------+
| *Captura tipo* (n = 243, missing 332 / 58%, 2 distinct)          |
+---------------------------------+--------------------------------+
| Places related to the victim    | 81                             |
+---------------------------------+--------------------------------+
| Public and institutional spaces | 162                            |
+---------------------------------+--------------------------------+
| *Vic grupo social* (n = 273, missing 302 / 53%, 5 distinct)      |
+---------------------------------+--------------------------------+
| Professionals                   | 145                            |
+---------------------------------+--------------------------------+
| Civil servants                  | 61                             |
+---------------------------------+--------------------------------+
| Students                        | 45                             |
+---------------------------------+--------------------------------+
| Other                           | 19                             |
+---------------------------------+--------------------------------+
| Organized crime                 | 3                              |
+---------------------------------+--------------------------------+

: Distribution of the three selected labels per victim after merging.
:::

Another issue of the human annotations is the lost documents. Many of
the decisions were made when the human coders were able to access more
documents than we currently can fetch, either from their sources or from
the internet. This means that some of the annotations are not supported
by the documents that are available to us. To address this issue, we
need to select the annotations that are supported by the documents that
are available to us. This is also critical for the goal of this project,
which is to relink the annotations to the source text and make them
usable for downstream tasks.

# Results

## Baseline versus Proposed Method {#baseline-vs-proposed-method}

The baseline for this evaluation is a simple summarization approach that
generates a direct summary of each victim's documents without codebook
guidance or structured extraction. The proposed method instead uses the
codebook schema to guide extraction and produces label-structured
summaries anchored to verbatim evidence spans. Each panel in
Figure [3](#fig:metrics_by_label){reference-type="ref"
reference="fig:metrics_by_label"} compares these two approaches on one
of the three selected labels, with 95% bootstrap confidence intervals
and a majority-class reference line.

The improvement is clearest for the outcome of the disappearance.
Extractive accuracy reaches 0.73 (95% CI 0.69--0.77) for Gemma 12B and
0.76 (0.71--0.80) for Ministral 8B, against baselines of 0.61 and 0.46
respectively; the Ministral gain of $+0.30$ is the largest in the
comparison, and for both models the confidence intervals of the two
conditions are well separated and the extractive estimates clear the
majority-class reference of roughly 0.59. Llama 8B improves more
modestly, from 0.48 to 0.55 ($+0.07$), and does not clear that
reference. Social group membership shows gains of $+0.10$ for Gemma
(0.33 to 0.43) and $+0.04$ for Ministral (0.40 to 0.43), while Llama
declines slightly ($-0.04$, 0.43 to 0.40); the confidence intervals for
this label overlap for all three models, so only the Gemma gain is
clearly distinguishable from noise. All three extractive estimates
nevertheless sit above the majority-class reference of roughly 0.34 for
this label. The type of place of disappearance remains the hardest
field: the proposed method improves over the baseline for every model
($+0.03$ to $+0.11$), but extractive accuracy stays between 0.32 and
0.34, *below* the majority-class reference of roughly 0.41. In other
words, for this label no model yet beats a degenerate classifier that
always predicts the most frequent category, and we treat the place
results as a negative finding that the error analysis in the appendix
traces to category ambiguity in the source texts.

Taken together, the proposed method improves over unconstrained
summarization in eight of nine model--label comparisons, with the
largest and statistically clearest gains on the outcome label; the gains
are real but heterogeneous, and the majority-class reference makes
visible which absolute levels are substantively useful and which are
not.

## Model Comparisons

<figure id="fig:metrics_by_label" data-latex-placement="tbp">
<img
src="./plots/evaluation/benchmarks/less_labels_multi_models/metrics_combined.png" />
<figcaption>Classification accuracy by model and label, baseline versus
proposed method. Each panel covers one of the three evaluated labels.
Within each panel, the pale point marks the simple summarization
baseline and the dark point the proposed extractive summarization; the
connecting segment shows the change, with the signed difference printed
in italics below it. Whiskers are 95% percentile bootstrap confidence
intervals (2<span>,</span>000 resamples over victims; <span
class="math inline"><em>n</em></span> = 370–575 per model). The dotted
vertical rule marks the accuracy of a majority-class classifier that
always predicts the most frequent annotated category in the merged label
space, evaluated on the same rows.</figcaption>
</figure>

Figure [3](#fig:metrics_by_label){reference-type="ref"
reference="fig:metrics_by_label"} also allows a cross-model comparison,
since each panel shows all three models on the same label. The models
differ in where they benefit most from the structured workflow.
Ministral 8B shows by far the largest gain on outcome ($+0.30$, reaching
0.76), Gemma 12B gains consistently on outcome ($+0.12$) and social
group ($+0.10$), while Llama 8B benefits least, with a modest gain on
outcome ($+0.07$), the largest gain of the three on place ($+0.11$), and
a small decline on social group ($-0.04$). For the type of place of
disappearance all three models remain in a narrow band between 0.32 and
0.34 under extractive summarization, confirming that this label is
difficult regardless of model. The improvement therefore does not depend
on a single model family, but its size is model-dependent, and the
weakest extractor (Llama 8B) is also the one whose spans are least often
verbatim in the source documents
(Section [6.4](#span-fidelity){reference-type="ref"
reference="span-fidelity"}).

The three models also span a range of parameter counts, with Llama 3.1
8B and Ministral 3 8B at 8 billion parameters and Gemma 3 12B at 12
billion. Despite this difference, Gemma does not uniformly outperform
the two smaller models. Ministral 8B reaches the highest extractive
accuracy on outcome (0.76 against Gemma's 0.73, with overlapping
confidence intervals), and the three models are statistically
indistinguishable on both place and social group. The 4 billion
parameter gap does not produce a consistent advantage on any label,
which suggests that within the 8B to 12B range the proposed workflow
provides comparable benefits regardless of model size.

## Comparison with Closed-Source Frontier Models {#closed-source-comparison}

The cross-model results in
Section [6.2](#model-comparisons){reference-type="ref"
reference="model-comparisons"} cover three open-source models in the
8B--12B parameter range. To check whether the proposed pipeline
transfers to substantially more capable models served through a
closed-source API, we re-ran the same extractive pipeline on a
deterministic 100-victim subsample (seed 42, 368 source documents) using
three models from the Claude 4.x family: Haiku 4.5, Sonnet 4.6, and Opus
4.7. Each model was prompted with the same codebook schema and the same
turn-by-turn update protocol used for the open-source runs, and the
resulting per-victim predictions were scored against the human
annotations after the same category-merging step applied throughout this
paper. Table [3](#tab:closed-source-comparison){reference-type="ref"
reference="tab:closed-source-comparison"} reports accuracy and Cohen's
$\kappa$ on the same 100-victim sample for all six models.

<figure id="fig:six_model_accuracy" data-latex-placement="tbp">
<img src="./plots/evaluation/benchmarks/six_model_kappa_forest.png" />
<figcaption>Agreement with human annotations (Cohen’s <span
class="math inline"><em>κ</em></span>) on the 100-victim subsample for
three open-source models (Llama 3.1 8B, Ministral 3 8B, Gemma 3 12B,
above the dashed divider) and three closed-source models from the Claude
4.x family (Haiku 4.5, Opus 4.7, Sonnet 4.6, below it), after
category-merging. Whiskers are 95% percentile bootstrap confidence
intervals (2<span>,</span>000 resamples over victims). The vertical rule
at <span class="math inline"><em>κ</em> = 0</span> marks chance
agreement: on the type of place of disappearance, all three open-source
models are statistically indistinguishable from chance, while all three
Claude models reach <span class="math inline"><em>κ</em></span> between
0.29 and 0.39.</figcaption>
</figure>

::: {#tab:closed-source-comparison}
+-------------------+-----------------------+-----------------------+---------------------------------------+
|                   | outcome               | social group          | place                                 |
+:==================+:=========:+:=========:+:=========:+:=========:+:=========:+:=========================:+
| 2-3 (lr)4-5       | Acc       | $\kappa$  | Acc       | $\kappa$  | Acc       | $\kappa$                  |
| (lr)6-7 Model     |           |           |           |           |           |                           |
+-------------------+-----------+-----------+-----------+-----------+-----------+---------------------------+
| Llama-3.1-8B      | 0.460     | 0.193     | 0.470     | 0.198     | 0.260     | $-$`<!-- -->`{=html}0.020 |
+-------------------+-----------+-----------+-----------+-----------+-----------+---------------------------+
| Ministral-3-8B    | 0.580     | 0.317     | 0.410     | 0.170     | 0.340     | 0.035                     |
+-------------------+-----------+-----------+-----------+-----------+-----------+---------------------------+
| Gemma-3-12B       | 0.650     | 0.381     | 0.430     | 0.165     | 0.310     | 0.003                     |
+-------------------+-----------+-----------+-----------+-----------+-----------+---------------------------+
| Claude-Haiku-4.5  | 0.717     | 0.549     | 0.576     | 0.385     | **0.596** | **0.394**                 |
+-------------------+-----------+-----------+-----------+-----------+-----------+---------------------------+
| Claude-Opus-4.7   | 0.646     | 0.362     | 0.667     | 0.477     | 0.586     | 0.371                     |
+-------------------+-----------+-----------+-----------+-----------+-----------+---------------------------+
| Claude-Sonnet-4.6 | **0.737** | **0.567** | **0.697** | **0.525** | 0.535     | 0.292                     |
+-------------------+-----------+-----------+-----------+-----------+-----------+---------------------------+

: Classification accuracy and Cohen's $\kappa$ on a fixed 100-victim
subsample, after category-merging. Open-source rows use the vLLM-served
configuration from
Section [6.2](#model-comparisons){reference-type="ref"
reference="model-comparisons"}; closed-source rows ran the same
extractive pipeline through the Anthropic API. The Claude $n{=}99$
figure reflects one victim whose human label was missing in the relevant
rows; differences across the $n{=}99$ vs $n{=}100$ rows are too small to
affect the comparison.
:::

Two findings stand out. First, every closed-source model outperforms
every open-source model on every label in point estimates, and the gap
is largest on the labels that the open-source runs handled least well.
On place of disappearance, where the bootstrap intervals in
Figure [4](#fig:six_model_accuracy){reference-type="ref"
reference="fig:six_model_accuracy"} show all three open-source models
statistically indistinguishable from chance agreement ($\kappa$ between
$-0.02$ and $0.04$), all three Claude models reach $\kappa$ between 0.29
and 0.39 with confidence intervals that exclude both zero and the
open-source estimates. On social group, where the open-source models
cluster at $\kappa \approx 0.17$--$0.20$, Sonnet reaches $\kappa = 0.53$
and Opus 0.48. On outcome, the open--closed gap is present but smaller,
and the intervals of the strongest open model (Gemma, $\kappa = 0.38$)
overlap with Opus (0.36). The gap is consistent with the interpretation
that closed-source models have a more reliable grasp of the codebook
distinctions on harder labels, while the proposed pipeline structure
continues to provide the same evidence-traceable scaffolding across the
entire model range.

Second, more capable models do not dominate uniformly within the Claude
family. Sonnet wins on outcome and social group, but Haiku wins on place
of disappearance and trails Sonnet on outcome by only two accuracy
points. Opus, the most capable model in the family, sits below Sonnet on
outcome and social group and below Haiku on outcome and place (though it
edges Sonnet on place); we attribute this to a more conservative
tendency to emit "No information" on ambiguous spans, which is the same
failure mode that lowers recall for open-source models on hard labels.
Given the overlapping bootstrap intervals within the Claude family,
these within-family orderings should be read as suggestive rather than
conclusive. For practitioners, this suggests that within the Claude 4.x
range Sonnet is the most reliable choice for this kind of
codebook-guided extraction, while Haiku is a competitive cost-efficient
option, especially on the hardest fields. Taken together with the
open-source results above, these comparisons support the broader claim
of this paper: the gains reported in
Section [6.1](#baseline-vs-proposed-method){reference-type="ref"
reference="baseline-vs-proposed-method"} are produced by the pipeline
structure, and stronger models add roughly additive, label-dependent
improvements on top.

## Span Fidelity

The pipeline's traceability claim rests on the extracted evidence spans
being verbatim excerpts of the source reports. Because the models are
instructed, not guaranteed, to copy text exactly, we audit this claim
directly rather than assume it. Every span recorded by the pipeline is
checked against the full set of source documents for its victim and
assigned to one of three tiers: *verbatim* (exact substring of a source
document), *near-verbatim* (matching after whitespace, casing, and
punctuation normalization, or a fuzzy partial match with similarity of
at least 90), and *not found* (no acceptable match anywhere in the
victim's documents). The open-source models are audited over their
full-corpus runs and the Claude models over the 100-victim subsample.
Figure [5](#fig:span_fidelity){reference-type="ref"
reference="fig:span_fidelity"} reports the results.

<figure id="fig:span_fidelity" data-latex-placement="tbp">
<img src="./plots/evaluation/benchmarks/span_fidelity.png" />
<figcaption>Span-fidelity audit. For each model, the share of extracted
evidence spans that are verbatim in the victim’s source documents,
near-verbatim (recoverable after normalization or with fuzzy matching at
similarity <span class="math inline"> ≥ 90</span>), or not found
anywhere in the victim’s documents. Open-source models (above the dashed
divider) are audited over their full-corpus runs, in which spans are
recorded at every conversation turn; Claude models (below) over the
final summaries of the 100-victim subsample, which accounts for the
difference in span counts <span
class="math inline"><em>n</em></span>.</figcaption>
</figure>

Fidelity varies dramatically across models and tracks the classification
results. Among the open-source models, Gemma 12B is the most faithful
extractor: 66 percent of its spans are verbatim and another 28 percent
near-verbatim, leaving only 5 percent unmatched. Llama 8B and Ministral
8B are substantially less reliable, with 33 and 39 percent of their
spans respectively not found anywhere in the victim's documents; these
spans are paraphrases at best and fabrications at worst, and they
quantify exactly the hallucination risk that motivates extractive rather
than abstractive summarization. The Claude models bracket the
open-source range: Opus 4.7 produces verbatim spans 86 percent of the
time with only 3 percent unmatched, Sonnet 4.6 is comparable to Gemma
(67 percent verbatim, 5 percent unmatched), while Haiku 4.5 copies
loosely (27 percent verbatim) but still leaves only 20 percent
unmatched.

A stricter test asks whether each span is verbatim in the specific
document it was attributed to, which is what the recorded character
offsets assume. Here the open-source models fare worse: only 34 percent
of Gemma's spans, 21 percent of Ministral's, and 17 percent of Llama's
are exact matches in their attributed document, with most of the
remaining verbatim spans matching a different document of the same
victim --- typically because a span extracted at an earlier turn is
re-emitted, slightly altered, while the conversation state is updated
against a later document. Two practical consequences follow. First, the
character-offset index is a reliable verification device only for spans
in the verbatim tier, and downstream users should treat near-verbatim
spans as locatable by fuzzy search rather than by offset. Second, span
fidelity is a model-selection criterion in its own right: the model with
the cleanest spans (Gemma among the open-source options) is also the
strongest open-source classifier in
Figure [4](#fig:six_model_accuracy){reference-type="ref"
reference="fig:six_model_accuracy"}, and an audit of this kind costs
only string matching, requires no human labels, and can be run before
committing to a model for a new corpus.

## Annotation to Documents Mapping

A central question for this pipeline is whether the original human
annotations can be traced back to evidence in the available source
documents and, where they cannot, whether the constraint is the state of
the archive rather than the quality of extraction.

<figure id="fig:matching_less_labels" data-latex-placement="tbp">
<img
src="./plots/evaluation/matching/less_labels_multi_models/joint_cdf_and_annotation_coverage.png" />
<figcaption>Annotation-to-document matching for the three selected
labels across three models. Top: for each (victim, model) pair that does
reach Full coverage, the distribution of the first turn at which it does
so; dots are individual victims, the box marks the IQR, the hollow
circle is the median, and italic counts on the right report pairs that
never reach Full coverage. Bottom: the number of victims with each level
of human annotation availability, split by whether the pipeline’s
machine classification fully or only partially covers those
annotations.</figcaption>
</figure>

The figure in this section combines two views of how well the pipeline
reconstructs the original human annotations. The top panel reports
per-label support coverage: for each (model, label) cell, the percentage
of (victim, model) pairs for which the labelled field was grounded in
extracted evidence at any turn during multi-turn processing. The bottom
panel reports per-victim annotation coverage: how many annotated labels
each victim carries, and whether every source document the original
coders consulted is still retrievable or whether only a subset remains
accessible.

Figure [6](#fig:matching_less_labels){reference-type="ref"
reference="fig:matching_less_labels"} shows two patterns that hold
across all three models. First, label difficulty varies markedly: the
outcome of the disappearance is the easiest field, supported in 49 to 62
percent of pairs, while social group membership is uniformly hard, with
all three models clustered in a narrow 31 to 33 percent band. The type
of place of disappearance sits in between at 37 to 41 percent. Second,
the models differ most where there is room to differ: on the outcome
field, Gemma 12B (62 percent) leads Ministral 8B (57 percent) and Llama
8B (49 percent) by a 13-point spread, while on the harder social group
field the three models converge within two points of each other.
Aggregating across labels, 16 percent of victim-model pairs end with all
three annotated labels supported and 44 percent end with at least two of
three; most of this coverage is reached within the first one or two
turns, so additional turns produce diminishing returns. The bottom panel
reports that 381 of the 427 annotated victims retain full document
coverage for these selected labels, while the remaining 46 have only
partial coverage because some of the documents the original coders
consulted are no longer retrievable. This 11 percent partial-coverage
rate sets a lower bound on what any extraction approach can achieve,
since annotations grounded in missing sources cannot be supported
regardless of model quality.

<figure id="fig:matching_all_labels" data-latex-placement="tbp">
<img
src="./plots/evaluation/matching/all_labels_one_model/joint_cdf_and_annotation_coverage.png" />
<figcaption>Machine classification coverage of human annotations for the
full 15-label codebook using Ministral 3 8B. Each bar pair shows, for a
given level of human annotation availability per victim, the number of
victims whose annotations are fully covered by the pipeline’s machine
classifications and the number whose annotations are only partially
covered. The 122 victims with no human annotations are excluded from the
panel and reported in the subtitle.</figcaption>
</figure>

The three selected labels were chosen for their low missing rates and
their broad relevance, but the full codebook contains many more coded
fields. Expanding the evaluation to extra categorical labels to include
15 labels in total to tests whether the pipeline can trace annotations
that carry higher missing rates and that encode more specialized
details. This is a harder test because full support now requires every
annotated field for a victim to be grounded in the available text.

Figure [7](#fig:matching_all_labels){reference-type="ref"
reference="fig:matching_all_labels"} reports the same measures for the
expanded label set using a single model. Full support drops to
approximately 8 percent, which is expected given that every annotated
label must now be matched simultaneously. At lower thresholds the
pipeline still recovers evidence for a substantial share of annotations:
71 percent of pairs reach at least 10 percent support and 53 percent
reach at least 25 percent. The critical constraint is visible in the
machine classification coverage panel, where only 234 of the 453
annotated victims retain full document coverage, falling from 89 percent
in the three-label setting to 52 percent when all labels are considered.
The remaining 219 victims have only partial coverage because news
articles that were available to the original human coders are no longer
be retrievable from their sources or from the internet. This is the
direct quantification of the lost documents problem introduced in the
evaluation design that the pipeline can only process the documents that
remain in the accessible archive, and any annotation that depended on a
source that has since disappeared sets a hard ceiling on the support
that can be recovered. The turn-by-turn recording that the pipeline
produces makes this ceiling visible and locatable. For the annotations
that can be traced, most pairs reach their threshold within the first
two documents. For those that cannot be fully traced, the recording
identifies precisely where the evidence trail ends, producing a concrete
inventory of what the pipeline recovers and what remains beyond reach
due to the state of the archive. This inventory is the practical
contribution of the tracing dimension: rather than treating missing
support as an unquantified limitation, the pipeline distinguishes
recoverable annotations from structurally unrecoverable ones and
documents the boundary between them.

::: {#tab:spans_example}
  victim_id                     label_key          span                                                                                                                                                offset
  ----------------------------- ------------------ ------------------------------------------------------------------------------------------------------------------------------------------------- --------
  Veracruz_J J R R              desenlace          "Hasta la fecha, sigue en la búsqueda, se ha convertido en detective..."                                                                              2480
  Veracruz_J J R R              vic_grupo_social   "Carmelo estudiaba arquitectura en una escuela privada de diseño. Su círculo de amigos era muy grande..."                                             2691
  N.L.\_Fabián H V              desenlace          "En el expediente no hay registros del plagio ni testimonios."                                                                                        2585
  Veracruz_María Victoria C T   captura_tipo       "Según Lorena, su madre y hermano fueron sustraídos de un taxi entre la calle 13 y avenida 11, frente al DIF Municipal, el pasado 17 de abril."       1254
  N.L.\_Fabián H V              captura_tipo       "Los perseguidores sustrajeron al empresario del vehículo siniestrado y se lo llevaron con rumbo desconocido en otra unidad, un Audi."                4109

  : Sample extracted spans per codebook field. Each span is a verbatim
  excerpt from the source document; the offset records the character
  position where the span begins in the original text.
:::

::: {#tab:summary_turns_example}
   turn   doc_id  info_found   labels found                                summary (excerpt)
  ------ -------- ------------ ------------------------------------------- ----------------------------------------------------------------------------------------------------------------------------------------
    0      \_1    FALSE        ---                                         (no summary produced)
    1      \_2    TRUE         desenlace, vic_grupo_social                 "Cuatro personas originarias de Sinaloa desaparecieron... fueron secuestrados por policías preventivos... y entregados a un cártel..."
    2      \_6    FALSE        ---                                         (previous summary preserved unchanged)
    3      \_8    TRUE         desenlace, vic_grupo_social, captura_tipo   "...siete jóvenes detenidos por policías locales y entregados a Los Zetas... la policía local colaboraba con el crimen organizado..."

  : Summary evolution across four turns for Coahuila_Ezequiel C T.
  Turns 0 and 2 process noisy documents that yield no information; the
  pipeline preserves the previous summary unchanged. Turns 1 and 3
  extract new evidence and update the running summary.
:::

Tables [4](#tab:spans_example){reference-type="ref"
reference="tab:spans_example"}
and [5](#tab:summary_turns_example){reference-type="ref"
reference="tab:summary_turns_example"} show abbreviated examples from
the full pipeline output for two of its recorded artifacts.
Table [4](#tab:spans_example){reference-type="ref"
reference="tab:spans_example"} presents a sample of extracted spans.
Each row records the victim identifier, the codebook field that the span
addresses, the verbatim passage extracted from the source document, and
the character offset where that passage begins in the original text.
Table [5](#tab:summary_turns_example){reference-type="ref"
reference="tab:summary_turns_example"} presents the turn-by-turn
processing trace for a single victim across four documents. Each row
records the turn index, the document identifier, whether relevant
information was found in that document, which codebook labels were
identified, and an excerpt of the running summary at that point. Both
tables are abbreviated selections from a larger output that the pipeline
produces for every victim in the corpus.

In Table [5](#tab:summary_turns_example){reference-type="ref"
reference="tab:summary_turns_example"}, the pipeline processes four
documents sequentially for one victim. At turns zero and two, the
documents contain no relevant information for the victim. These are the
noisy, irrelevant, or damaged pages that are common in web-scraped
corpora, such as error pages, log in pages, or unrelated articles
scraped alongside the target content. When the pipeline encounters such
documents, it preserves the existing summary unchanged rather than
letting irrelevant content dilute or degrade the evidence already
collected. At turns one and three, the pipeline finds relevant
information and updates the running summary accordingly. The set of
supported codebook labels grows from two at turn one, where the pipeline
identifies outcome and social group, to three at turn three, where it
additionally identifies type of place of capture. This progressive
enrichment shows that evidence for different codebook fields can be
distributed across multiple documents and that the stateful design
accumulates labels as informative documents are encountered. In
Table [4](#tab:spans_example){reference-type="ref"
reference="tab:spans_example"}, the character offset for each extracted
span records the exact position in the source document where the
evidence begins. A researcher can return to the original text at the
recorded offset and verify that the extracted passage appears at that
location, making each piece of evidence independently checkable against
the source.

The combination of verbatim spans, character offsets, and turn-by-turn
processing traces means the pipeline output is auditable at the level of
individual evidence claims. A researcher can follow the chain from a
codebook label to the extracted passage that supports it to its
character position in the source document to the specific processing
turn that produced it. At the aggregate level, the support coverage
analysis identifies which annotations fall within reach of the available
archive and which are structurally unrecoverable because of the lost
documents problem. At the instance level, the extracted spans and turn
traces document precisely what was recovered and where the evidence
trail ends. These two dimensions produce a complete account of the
annotation-to-document mapping: the pipeline does not only classify but
records the evidence path for each annotation it can trace and flags the
structural reason for each one it cannot.

# Discussion

## Compute Time vs Human Coding

An important implication of the proposed workflow is that it changes the
cost structure of working with inherited annotations. Recreating the
earlier coding process would require retraining coders, rereading
multiple reports for each victim, and reconstructing decisions that were
never formally preserved, whereas the pipeline can process the same
material in hours while recording each turn of evidence extraction and
summary updating. The gain is therefore not only speed, but a different
use of scarce expert labor. Instead of spending weeks on repetitive
document cleaning, reconciliation, and aggregation, researchers can
direct human effort toward validating difficult cases, resolving
ambiguous categories, and interpreting substantive patterns in the data,
while the repetitive parts of the task are taken care of by the LLMs.
For projects that inherit valuable but imperfectly organized
annotations, this makes reuse of prior coding work far more feasible
than full manual reconstruction.

## Scalability to Other Messy Corpora

A broader value of the proposed method lies in the type of problem it
addresses rather than in the specific corpus used here. Many research
projects inherit messy text and annotation collections in which reports
are organized for one purpose, annotations were created for another, and
the link between coded variables and supporting evidence was never
formally retained. In such settings, the transferable contribution is
the workflow design itself the codebook-guided extraction,
evidence-linked summaries, and stateful updating across multiple
documents. This portability is possible because the workflow is designed
to be configurable rather than hardcoded. Separate configuration files
and taxonomies can define the local labels, extraction targets, and
field structure for a new corpus while leaving the underlying pipeline
logic unchanged. Adapting the method to a new corpus would therefore
require changing the task schema and prompts to fit the local annotation
system, but not redesigning the full logic of the pipeline. This
suggests that the approach can generalize to other legacy corpora where
researchers need to recover usable and traceable structured text from
noisy materials without repeating the original annotation process from
the beginning.

## Fine-Tuning on Pipeline Output {#sec:finetuning}

The fine-tuning dataset is constructed as follows. For each victim, the
pipeline produces a final structured summary in which every codebook
field is populated with verbatim spans extracted from the source
reports. These summaries are paired with the corresponding human
annotations for fields such as case outcome (*desenlace*), victim social
group (*vic_grupo_social*), and type of place of capture
(*captura_tipo*). Each training instance therefore consists of a clean,
evidence-grounded summary as input and one or more categorical labels as
the target. Because the summaries are already organized label by label,
the fine-tuning input can be formatted either as a full summary for
multi-label prediction or as a per-field segment for single-label
classification, depending on the downstream task design. In the current
corpus, the annotated subset provides up to 393 labeled instances for
*desenlace*, 273 for *vic_grupo_social*, and 243 for *captura_tipo*,
each with the corresponding pipeline-cleaned summary as the text input.

To validate this empirically, we compare classification performance when
models are trained on the original raw messy text versus the
pipeline-cleaned summaries, using stratified 5-fold cross-validation
across all three selected labels. Traditional TF-IDF bag-of-words
classifiers favor the raw text due to its greater lexical volume: the
mean raw document length per victim is approximately 28,000 characters
compared to roughly 700 characters for the summaries, providing more
discriminative n-grams even though many come from navigation menus or
unrelated content. However, this advantage disappears when the
classifier operates semantically.
Table [6](#tab:finetuning_encoder){reference-type="ref"
reference="tab:finetuning_encoder"} reports results using multilingual
sentence-transformer embeddings (paraphrase-multilingual-MiniLM-L12-v2)
followed by logistic regression. The pattern reverses on two of the
three labels: for *desenlace*, summaries achieve a macro F1 of 0.723
compared to 0.656 on raw text, a gain of +0.067; for *vic_grupo_social*,
summaries reach 0.484 compared to 0.418, a gain of +0.066. For
*captura_tipo*, the two inputs perform comparably at 0.587 and 0.600
respectively, consistent with this being the most difficult label across
all experiments. The $\kappa$ values follow the same pattern, with
summaries showing stronger agreement on *desenlace* (0.450 vs. 0.315)
and *vic_grupo_social* (0.376 vs. 0.335).

::: {#tab:finetuning_encoder}
  Label ($N$)              Input                   Accuracy                             Macro F1                               $\kappa$
  ------------------------ ---------- ---------------------------------- -------------------------------------- --------------------------------------
  Outcome (381)            Raw text    0.701$\pm$`<!-- -->`{=html}0.041     0.656$\pm$`<!-- -->`{=html}0.048       0.315$\pm$`<!-- -->`{=html}0.095
                           Summary     0.758$\pm$`<!-- -->`{=html}0.023   **0.723**$\pm$`<!-- -->`{=html}0.029   **0.450**$\pm$`<!-- -->`{=html}0.055
  Social Group (263)       Raw text    0.620$\pm$`<!-- -->`{=html}0.042     0.418$\pm$`<!-- -->`{=html}0.047       0.335$\pm$`<!-- -->`{=html}0.078
                           Summary     0.639$\pm$`<!-- -->`{=html}0.037   **0.484**$\pm$`<!-- -->`{=html}0.065   **0.376**$\pm$`<!-- -->`{=html}0.069
  Place of Capture (241)   Raw text    0.697$\pm$`<!-- -->`{=html}0.061   **0.600**$\pm$`<!-- -->`{=html}0.075   **0.232**$\pm$`<!-- -->`{=html}0.136
                           Summary     0.697$\pm$`<!-- -->`{=html}0.048     0.587$\pm$`<!-- -->`{=html}0.091       0.211$\pm$`<!-- -->`{=html}0.157

  : Classification performance (stratified 5-fold CV) using multilingual
  sentence-transformer embeddings with logistic regression on raw messy
  text vs. pipeline-cleaned summaries. Best macro F1 per label shown in
  bold. $N$ denotes the number of victims with both a valid label and
  summary.
:::

These results confirm that when models process text semantically rather
than lexically, the clean and concentrated pipeline summaries outperform
the noisy raw documents. Since LLM fine-tuning operates on the semantic
end of this spectrum,
Table [6](#tab:finetuning_encoder){reference-type="ref"
reference="tab:finetuning_encoder"} provides the more relevant baseline
for the downstream use case. Because the pipeline records which evidence
spans support each label, training instances can be augmented with
span-level supervision, enabling fine-tuned models to learn not only the
correct label but also which parts of the text are relevant to that
label, a form of rationale-augmented training.

The fine-tuning procedure itself follows standard practice for
instruction-tuned language models. The pipeline summaries and their
associated labels are formatted as prompt--completion pairs, where the
prompt contains the structured summary text and the codebook field
definition, and the completion contains the target label.
Parameter-efficient methods such as LoRA can be applied to adapt smaller
open-source models, for instance a 7B or 8B parameter model, on this
labeled data without requiring full-weight training. Because the
summaries are already constrained to the codebook schema and written in
the same structured format regardless of which extraction model produced
them, the fine-tuning data is consistent in format and length, which
simplifies training and reduces variance across batches.

The practical implication is that the pipeline enables a two-stage
division of labor in which large, general-purpose models handle the
expensive extraction and summarization at inference time, and the
resulting clean outputs are used to train smaller, cheaper models that
can be deployed for classification at scale without requiring continued
access to a large model endpoint. Once fine-tuned, these smaller models
can classify new summaries produced by the same pipeline for new victims
or new corpora at a fraction of the inference cost. This fine-tuning
pathway also opens the possibility of iterative improvement: as domain
experts review and correct the pipeline classifications, those
corrections can be folded back into the training data to produce
progressively better task-specific models. The pipeline therefore
functions not only as a one-time cleaning tool but as infrastructure for
generating and refining supervised training data from legacy corpora
that were never originally annotated at the granularity that modern
fine-tuning workflows require.

## Downstream Tasks

When developing new research projects using the UMN dataset, we are
particularly interested in analyzing how violence is portrayed,
described, documented, or obscured through language in public reporting,
especially in ways that prevent the systematic and/or generalized
identification of human rights violations and international crimes. Our
work focuses on identifying the use of euphemisms, ambiguous
terminology, and narrative framing that mask patterns of violence and
make it more difficult to establish the widespread and/or systematic
nature of abuses---an essential requirement for proving international
crimes before courts. By analyzing large corpora of media reports and
related documentation, we aim to understand how linguistic practices can
shape the visibility of violence and influence whether certain acts are
recognized as human rights violations or international crimes.

One specific focus of our research using the UMN dataset concerns the
terminology that emerged during Mexico's so-called "War on Drugs,"
declared by President Felipe Calderón in 2006. During this period,
journalists increasingly used the term "levantón" ("big lift") to
describe events involving the deprivation of liberty followed by the
disappearance of individuals whose fate and whereabouts remained
unknown. Although some journalists now employ more accurate terminology,
many reports still frame disappearances primarily as ordinary criminal
acts rather than as serious human rights violations or international
crimes, often overlooking the possible role of the state through action,
tolerance, or omission, in collusion with organized crime. Our research
seeks to examine how such language contributes to the normalization or
depoliticization of disappearances in public discourse.

Presenting disappearances as isolated crimes creates several analytical
and legal problems. First, it reduces the event to a single act of
deprivation of liberty rather than recognizing disappearances as a
continuous and ongoing crime that persists as long as the person's fate
and whereabouts remains unknown. Second, it obscures the multiple human
rights violations involved, including violations of the rights to life,
personal integrity, and juridical personality, and ignores the broader
circle of victims affected by the disappearance. Finally, it conceals
the possible involvement of the state, which is central to the legal
definition of enforced disappearances. The use of terms like "levantón"
is particularly problematic because it originates in the lexicon of
organized crime and functions as a euphemism that masks what may in fact
be a crime of disappearances. Through systematic analysis of this
language, our research seeks to reveal how linguistic framing can
obscure patterns of violence that are essential for legal accountability
and human rights documentation.

# Conclusion and Future Work

The central obstacle in working with inherited messy text is not noise
alone, but the broken connection between prior human coding and the
source evidence on which that coding depended. The proposed
codebook-guided extractive summarization workflow addresses that gap by
producing clean, evidence-linked summaries that remain traceable to the
original reports and usable for downstream language model tasks. It
offers a practical way to preserve and reactivate costly human judgment
that would otherwise remain trapped inside legacy annotations, while
shifting scarce expert labor away from repetitive reconstruction and
toward validation, interpretation, and substantive analysis.

Future work can build on this recovered representation as research
infrastructure for organizing text datasets by a schema driven by
codebook definitions for cumulative human rights research, future
investigations, historical reconstruction, policy making, and
accountability over time. In that role, it can help sustain shared
evidence across long term collaborative projects and make structured
documentation more usable for local organizations, independent
researchers, victims, and affected communities, and could be applied to
existing efforts such as the Notre Dame Legacy Project's archive of the
Colombian Truth Commission [@LegacyProject].

#  {#section .unnumbered}

# Appendix

## Ethical Considerations

Masking victim names in the dataset is an important measure to protect
the privacy, dignity, and security of victims and their families. Cases
involving disappearances and other forms of violence often remain
politically sensitive and may involve powerful actors, including
criminal organizations or state agents. Publicly circulating
identifiable personal information can expose victims' relatives to
intimidation, retaliation, or renewed stigmatization. By anonymizing
names while preserving the relevant contextual data---such as dates,
locations, and types of violations---the dataset allows researchers to
analyze patterns of violence without placing individuals or families at
additional risk.

Anonymization also reflects broader ethical standards in human rights
research and documentation, which prioritize the protection of victims
over the unrestricted dissemination of personal information. Masking
identities helps prevent the re-victimization of families and respects
their right to control how their loved ones' stories are used and
shared. The dataset remains analytically valuable because the key
variables needed to study trends, language, and patterns of violence are
preserved, enabling rigorous research while maintaining responsible
safeguards for those directly affected by the crimes being documented.

<figure id="fig:appendix_http_error_page" data-latex-placement="p">
<img src="./plots/sample_reports/Guerrero_Abel_A_G_2.png"
style="width:90.0%" />
<figcaption>Example of an HTTP error page in the scraped
corpus.</figcaption>
</figure>

<figure id="fig:appendix_website_formatting" data-latex-placement="p">
<img src="./plots/sample_reports/Coahuila_Abel_M_H_1.png"
style="width:90.0%" />
<figcaption>Example of ancillary website formatting interleaved with
report content.</figcaption>
</figure>

<figure id="fig:appendix_distractive_content" data-latex-placement="p">
<img src="./plots/sample_reports/Coahuila_Bernando_A.png"
style="width:90.0%" />
<figcaption>Example of distractive but topically adjacent content
appended to a report.</figcaption>
</figure>

<figure id="fig:desenlace_distribution" data-latex-placement="p">
<img
src="./plots/descriptive_statistics/desenlace_distribution_by_victim_before_merging.png"
style="width:80.0%" />
<figcaption>Distribution of desenlace categories per victim before
merging.</figcaption>
</figure>

<figure id="fig:captura_tipo_distribution" data-latex-placement="p">
<img
src="./plots/descriptive_statistics/captura_tipo_distribution_by_victim_before_merging.png"
style="width:80.0%" />
<figcaption>Distribution of captura tipo categories per victim before
merging.</figcaption>
</figure>

<figure id="fig:vic_grupo_social_distribution" data-latex-placement="p">
<img
src="./plots/descriptive_statistics/vic_grupo_social_distribution_by_victim_before_merging.png"
style="width:80.0%" />
<figcaption>Distribution of vic grupo social categories per victim
before merging.</figcaption>
</figure>

## Rule-based Preprocessing and its Limits {#app:preprocessing}

To address these noise sources, the authors attempted to rescrape the
original URLs to obtain cleaner versions of the documents. However, a
portion of the original URLs were no longer accessible at the time of
rescraping. For those that remained available, the structural issues
persisted, as the noise originates from the design of the source
websites themselves rather than from the scraping process. Navigation
menus, comment sections, and related article modules are integral parts
of the page layout and are captured by any general-purpose scraper that
retrieves the full page body.

The authors also attempted rule-based preprocessing to remove known
sources of noise, targeting HTML tags, residual markup, and other
structural elements. While this reduced formatting noise, it could not
reliably eliminate all types of errors such as navigation text or other
irrelevant information, because each webpage were designed differently.
As for related content such as suggested articles or comment threads
which appear as valid plain text, are almost indistinguishable from
article content by pattern-matching rules. Processing them requires
substantive human hours and is not scalable. Approaches such as optical
character recognition (OCR), which convert image-based documents to
machine-readable text, are not applicable here, as the documents were
already scraped as plain text. The noise in this corpus is not an
accessibility problem but a content boundary or scope problem, and no
rule-based or format-conversion method can reliably locate where the
article body ends and extraneous content begins without semantic
understanding of the text.

## Limitations

One limitation of this study is how performance is evaluated against a
codebook where categories are not always sharply separable in the source
text. Some reports contain descriptions that can reasonably support more
than one label, so disagreement between the model output and the human
annotation does not always mean that the summary failed to preserve the
relevant information. In these cases, lower accuracy can partly reflect
ambiguity in the source material and overlap in the taxonomy, especially
for labels where valid interpretations remain close to one another. We
mitigate part of this problem by merging some label options, but that
adjustment also reduces category detail and makes the comparison less a
direct reproduction of the original coding scheme. Even though the
proposed workflow is not a full reconstruction of the original coding
scheme, it is still a practical way to reconnect prior annotations to
the source texts and recover traceable evidence for downstream use.

## Error analysis

Three identifiable sources of error affect the pipeline at different
stages. The first is document-level noise from error pages, navigation
menus, advertising banners, and topically adjacent but irrelevant
content that pervade the web-scraped corpus. LLM-based data
standardization and error processing can handle such noise through
contextual extraction and generation rather than rule-based methods. The
pipeline applies this principle by using the codebook schema to focus
extraction on relevant fields, so that noisy content is filtered during
the extraction step itself rather than requiring a separate
preprocessing stage. The span-fidelity audit in
Section [6.4](#span-fidelity){reference-type="ref"
reference="span-fidelity"} quantifies, for each model, how often this
extraction step nevertheless emits text that is not verbatim in the
source, which bounds the residual hallucination risk at the span level.

The second source is missing evidence from the lost documents problem.
When source articles consulted by the original coders are no longer
retrievable, annotations that depended on those sources cannot be
grounded regardless of extraction quality. The pipeline addresses this
by recording which annotations remain unsupported after all available
documents have been processed and by distinguishing structural absence
of the source from the archive from extraction failure through the
support ceiling and turn-by-turn recording. This makes the gap
attributable and quantifiable rather than hidden within the overall
accuracy figures.

The third and likely largest source of error is ambiguity in the
categorization of certain texts. Some labels have options that overlap
in meaning or that require contextual judgments the source text does not
resolve unambiguously. When a report can reasonably support more than
one category, the human coder and the model may arrive at different but
defensible assignments, and this disagreement registers as a
classification error even though the summary correctly preserved the
relevant information. These failure modes being knowable and separable
itself is a contribution to methodological transparency in computational
social science, because it lets researchers make informed choices about
when and how to use the output.

## Annotators Original Coding Manual

This is the document used by the coders when reviewing the news corpora.

::: center
**Mexico Disappearances Database: Coahuila and Nuevo León\**

Coding Manual
:::

The objective of this manual is to standardize the ways in which the
coding team records cases of disappearances, as represented in major
newspaper and media sources in the Mexican states of Coahuila and Nuevo
León. One will find in this document instructions for how to respond to
each question and the criteria that each coder should use when making
entry decisions.\
**Evento\**

Q1. Nombre codificadora/or - Name of Coder\
First and last name of the coder

Q2. Nombre del Evento (Comenzar con "Desaparición de")\
Name of Event (Begin with "Desaparición de") Unless there is an official
name for the event (such as Ayotzinapa 34), the event is named after the
individual disappeared. Example: "Desaparición de José González"

Q3. Fuente Periódico - Newspaper\
Official name of the newspaper with the Mexican state in parentheses.
Example: El Norte (Nuevo León)

Q4. Artículo(s) de la Noticia (Citación del Estilo de Chicago) -
Article(s) of the Newspaper (Chicago Style Citation)\
Cite in Chicago Style all articles you will use to answer the questions.
For a brief guideline for how to cite in Chicago Manual of Style (16th
Edition), visit the Purdue Online Writing Lab's Chicago Style webpage:
https://owl.english.purdue.edu/owl/resource/717/01/.

**Víctima\**

Q5. Nombre de Pila - Name of Victim\
Enter the full name of the victim

Q6. Alias - Alias\
Enter the known alias of the victim, if it exists.

Q7. Sexo - Sex\
Enter the sex (male - female binary) of the victim.

Q8. Edad al momento de la desaparición - Age at the time of
disappearance\
Enter the age of the victim, if it is given or if you can figure it out
from the information in the article.

Q9. Lugar de nacimiento - Place of birth\
Enter the place of birth (format: City, State) of the victim, if it is
given.

Q10. Nacionalidad - Nationality\
Select or enter the nationality of the victim. If "other," specify in
the Spanish feminine form ("otra").

Q11. Situación migratoria al momento de la desaparición - Migratory
status at the time of disappearance\
Select or enter the migratory/citizenship status of the victim.

Q12. Domicilio habitual - Residence\
Enter the residency (format: City, State) of the victim.

Q13. Escolaridad - Education\
Enter the highest level of education of the victim, regardless of
whether he or she holds a degree at that level. Example: If the victim
were in his or her second year of the equivalent of high school (but had
not graduated), one would still select "Secundaria - Secondary." For
university studies, select "other" and enter "Universidad," followed by
the subject. Example: Other: Universidad: Filosofia

Q14. Ocupación - Occupation\
Enter the occupation of the victim, if it is given.

Q15. ¿La víctima tiene familiar(es) inmediato(s)? Does the victim have
(an) immediate family member(s)?\
Select whether the victim has an immediate family members and list all
that are known. If so, enter the number. Immediate family members
include: parents, siblings, children, and spouse. Example: 3 (Madre,
Padre, Hermano)

Q16. Orientación sexual de la víctima - Sexual orientation of the
victim\
Enter the sexual orientation of the victim, if it is given.

Q17. ¿La víctima pertenece a algún pueblo indígena? - Is the victim a
member of an indigenous population?\
Select whether the victim belongs to a particular indigenous group. If
so, enter the name.

Q18. ¿Pertenece la víctima a algún grupo social distintivo? - Is the
victim a member of a distinct social group?\
Select the particular social group to which the victim belongs, if it is
given.

Q19. Especificar grupo/pertenencia - Specify group\
If a particular social group is given, specify the group name. Example:
PAN, Católicismo, etc.

Q20. Otros rasgos físicos relevantes de la víctima - Other relevant
characteristics of the victim\
List any other physical characteristics of the victim you deem relevant
and/or important.

Q21. ¿Aparece en el RNPED? - Does the victim appear in the RNPED?\
Search whether the individual is listed in the National Registry, RNPED:
https://rnped.segob.gob.mx/. We suggest entering the gender of the
victim in RNPED and an age range of 0-90, and the corresponding
state(s). Search in both tabs, "Fuero Federal" and "Fuero Común"

Q22. Víctima: Otra información importante - Victim: Other important
information\
List any other information about the victim you deem important for the
case that is not captured in questions five to 21.

**Hechos\**

Q23. Amenaza(s) previa(s) - Previous threat(s)\
Select whether there have been previous threats made against the victim.

Q24. ¿Quién?\
Select and/or list who made the previous threats.

Q25. ¿Sobre qué? - About what?\
Select and/or enter what is known about the previous threats.

Q26. Método de captura/desaparicion - Method of capture/disappearance\
Select and/or enter the method through which the victim had been
captured, if it is given.

Q27. Fecha de captura:\
Enter the date of capture of the victim, if given. If only the month and
year is known, leave the day blank. If date of capture is unknown, enter
the date of last seen.

Q28. Localización de desaparición o lugar de fue visto por última vez -
Location of disappearance or place where they were last seen\
Enter the location (format: City, State) of the location of
disappearance, if given.

Q29. Tipo de lugar de desaparicion - Type of place of disappearance\
Select the type of place of disappearance of the victim, if given.
Examples of public locations include generally state-run areas: streets,
parks, airports, etc. Examples of private locations include places owned
by individuals or businesses: homes, restaurants, stores, etc.

Q30. Medio(s) de captura/desaparición. Arma(s) - Mean(s) of
capture/disappearance. Arm(s)\
Select and/or enter the means of capture, with regards to the
(suspected) perpetrator being armed, if given.

Q31. Medios de captura/desaparición. Vehículos - Means of
capture/disappearance. Vehicles\
Select and/or enter the means of capture, with regards to the type of
vehicle used by the (suspected) perpetrator. Examples of official
vehicles are police vehicles, military vehicles, etc. Private vehicles
are vehicles belonging to a private person or entity.

Q32. Traspasos - Transfers\
Detail whether, who, what, where, when, and why there had been transfers
of the victim from one place to another or one vehicle to another, if
given.

Q33. Cautiverio - Captivity\
Select whether the victim had been held in captivity, if given.

Q34. Testigo(s) - Witness(es)\
Select whether there had been witnesses to the disappearance, if given.

Q35. Relación del/de los testigo(s) con la víctima - Relation of the
witness(es) to the victim\
Select the nature of the relationship of the witness(es), as it/they
relate(s) to the victim.

Q36. Desenlace - Outcome\
Select and/or enter what the outcome is of the disappearance, if it is
given.

Q37. Fecha de desenlace - Date of outcome\
Enter the date of the outcome, if given. If only the month and year are
known, leave the day blank.

Q38. Localización desenlace - Location of outcome\
Enter the location of the outcome (format: City, State), if given.

Q39. Tipo de lugar de desenlace (nombre, página 152 del Tesauro de
HURIDOCS) - Type of place of outcome (name, page 152 of the HURIDOCS
Thesaurus)\
Enter the type of place of the outcome (number), as given on page 152 of
the Spanish HURIDOCS thesaurus.

Q40. Hechos: Otra información importante - Facts: Other important
information\
List any other information about the facts you deem important for the
case that is not captured in questions 23 to 39.

**Perpetradores\**

Q 41. Perpetradores. Cantidad - Perpetrators. Quantity\
Select the number of perpetrators, if given.

Q42. Categoria de probable perpetrador - Category of probable
perpetrator\
Select the type(s) of probable perpetrators, if given. Even if this
information is alleged and not confirmed, please report it. Click all
categories that are reported in the narrative as probable perpetrators,
(e.g. if armed perpetrators were wearing state police vests, but unsure
if they were actually police, select Policía Estatal + Grupos o
individuos vinculados al crimen organizado)

Q43. Relación con la víctima - Relation to the victim\
Select and/or enter the relationship between that the perpetrator(s)
has/have to the victim, if given.

Q44. Involucramiento del perpetrador - Involvement of the perpetrator\
Select and/or enter the ways in which the perpetrator(s) was/were
involved in the disappearance, if given.

Q45. Perpetradores: Otra información importante - Perpetrators: Other
important information\
List any other information about the perpetrators you deem important for
the case that is not captured in questions 41 to 44.

**Procedimiento Judicial\**

Q46. Contactos oficiales. Cantidad - Official contacts. Quantity\
Enter the number of contacts that the family, and/or friend(s), and/or
representative(s), and/or organization(s) has/have had with officials,
if given. Officials include police, prosecutors, etc.

Q47. Persona(s) que hicieron el/los contacto(s) - Person(s) who made the
contact(s)\
Select the type of people who have made contacts, if given.

Q48. Contactos: ¿Con quién? ¿Qué respuestas? - Contacts: With whom?
Which responses?\
Select the type of responses associated with each person contacted. If
"no information," select the cross row-column "sin información - sin
información."

Q49. En caso de seleccionar \"Other(s)\" de las hileras a la izquierda,
especificar - In the case of selecting \"Other\" from the rows on the
left, specify.\
Specify the "Otra(s)" from the previous question (48).

Q50. ¿Se presentó el caso a una instancia de activación de búsqueda de
personas? - Was a search for the victim activated?\
Select whether an official victim search has been activated, if given.

Q51. Fecha de activación del mecanismo - Date of mechanism activated\
Select the date when the victim search was activated, if given. If only
the month and year are given, leave the day blank.

Q52. ¿Interpuso una denuncia penal? Has a penal complaint been lodged?\
Select whether a penal complaint has been lodged against the (suspected)
perpetrator(s).

Q53. Estatus de las órdenes de aprehensión - Status of the arrest
warrant\
Select the status of the arrest warrant against the (suspected)
perpetrator(s), if given.

Q54. Características de el/los detenido(s) - Characteristics of the
detained individual(s)\
Select all the appropriate characteristics that apply to the detained
individaul(s)

Q55. Se ha inició un proceso judicial? - Has a court case been
initiated?\
Select whether a court case has been initiated, if given.

Q56. Tipo de tribunal en el que se abrió el expediente judicial - Type
of court in which the case file was opened\
In reference to question 55, select what type of court it is in which
the case file is opened, if given.

Q57. Sentencia - Sentence\
Select whether a sentence has been given against the
perpetrator(s)/detained individual(s) against whom the court case was,
if given.

Q58. Tipo de sentencia - Type of sentence\
Select all appropriate types of sentences given against the
perpetrator(s)/detained individual(s) against whom the court case was,
if given.

Q59. Procedimiento Judicial: Otra información importante - Judicial
procedure: Other important information\
List any other information about the judicial procedure you deem
important for the case that is not captured in questions 46 to 58.

**Observaciones y Comentarios\**

Q60. Observaciones y comentarios - Observations and comments\
Enter any other observations or comments that you deem important for the
case, as a whole, that may not fit into questions 22, 40, 45, and/or 59.

[^1]: This research was supported by NSF award OAC-2311142 and used
    Delta at NCSA / University of Illinois through allocation CIS220162
    from the Advanced Cyberinfrastructure Coordination Ecosystem:
    Services & Support (ACCESS) program, which is supported by NSF
    awards 2138259, 2138286, 2138307, 2137603, and 2138296. Any
    opinions, findings, and conclusions or recommendations expressed in
    this material are those of the author(s) and do not necessarily
    reflect the views of the National Science Foundation, NCSA, or the
    affiliated university resource providers.\
    The data here were created initially by researchers from the Human
    Rights Program at the University of Minnesota to explore Mexican
    press reporting in four states in Mexico from 2009-2018. The Press
    Reporting project is affiliated with the Observatory on
    Disappearances and Impunity in Mexico, based at UNAM and FLACSO in
    Mexico City (<https://odim.juridicas.unam.mx/>). We acknowledge the
    Principal Investigator on the initial data collection and
    annotation, Barbara Frey, J.D., director of the Human Rights Program
    from 2001-2022. The Project Coordinator was Maria Ignacia Terra. The
    primary researchers on the project included: Yolanda Burckhardt,
    Maria Larson, Rosaleen Joyce, Hunter Johnson, Olga Salazar Pozos and
    Paula Cuellar Cuellar. Thanks also to Dr. Carrie Booth Walling,
    director of the Human Rights Program, for ongoing maintenance of the
    database. The original database was supported with funding from
    Fulbright-COMEXUS, the University of Minnesota Human Rights
    Initiative and the Ohanessian Endowment Fund for Justice and Peace
    Studies.

[^2]: The coding rules used by the human annotators are given in
    Appendix [9](#appendix){reference-type="ref" reference="appendix"}.
